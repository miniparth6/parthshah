# Parth Shah — SEO Website (Vercel-ready)

A minimal Next.js website for your SEO profile + packages. Deployed easily on Vercel.

## Local setup
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
npm start
```

## Deploy to Vercel (two options)

**Option A: GitHub Import**
1. Push this folder to a new GitHub repo.
2. Go to https://vercel.com/new and select the repo.
3. Framework Preset: **Next.js**. Keep defaults. Click **Deploy**.

**Option B: Vercel CLI**
```bash
npm i -g vercel
vercel
# follow prompts (scope, project name, link project, build command auto-detected)
vercel --prod
```

## Replace the proposal PDF
Replace `public/seo-proposal.pdf` with your latest proposal file to update the download button.

---
Built with Next.js App Router.
