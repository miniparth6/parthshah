import Link from "next/link";
import "./globals.css";

function PackageRow({ feature, basic, standard, premium }:{feature:string,basic:string,standard:string,premium:string}){
  return (
    <tr>
      <td>{feature}</td>
      <td>{basic}</td>
      <td>{standard}</td>
      <td>{premium}</td>
    </tr>
  )
}

export default function Page(){
  return (
    <main>
      <section className="container hero">
        <div>
          <h1 style={{fontSize:42, margin:0}}>Parth Shah — Digital Marketing & SEO Expert</h1>
          <p style={{fontSize:18, color:"var(--muted)"}}>Boost Your Online Visibility with Proven SEO Strategies.</p>
          <div style={{display:"flex", gap:12, marginTop:12}}>
            <a className="btn primary" href="/seo-proposal.pdf" target="_blank" rel="noreferrer">Download SEO Proposal (PDF)</a>
            <a className="btn" href="mailto:miniparth6@gmail.com">Contact Me</a>
            <a className="btn" href="tel:+917600875743">Call: +91 7600875743</a>
          </div>
        </div>
        <div className="card">
          <h3 style={{marginTop:0}}>About Me</h3>
          <p>
            I’m Parth Shah, specializing in SEO, PPC & Social Media Marketing. I help businesses grow their
            organic traffic and leads with ethical, data-driven SEO.
          </p>
          <p>
            <strong>Email:</strong> <a href="mailto:miniparth6@gmail.com">miniparth6@gmail.com</a> &nbsp;·&nbsp;
            <strong>Phone:</strong> <a href="tel:+917600875743">+91 7600875743</a>
          </p>
        </div>
      </section>

      <section className="container card">
        <h2 style={{marginTop:0}}>SEO Packages (INR ₹)</h2>
        <div style={{overflowX:"auto"}}>
          <table>
            <thead>
              <tr>
                <th>Features</th>
                <th>Basic</th>
                <th>Standard</th>
                <th>Premium</th>
              </tr>
            </thead>
            <tbody>
              <PackageRow feature="Monthly Cost (₹)" basic="₹6,500" standard="₹10,000" premium="₹13,000+" />
              <PackageRow feature="Target Keywords" basic="Up to 10" standard="Up to 25" premium="50+" />
              <PackageRow feature="Website Audit" basic="✅" standard="✅" premium="✅ Advanced" />
              <PackageRow feature="Competitor Analysis" basic="Basic" standard="In-depth" premium="Advanced + Report" />
              <PackageRow feature="Keyword Research" basic="Basic" standard="Detailed" premium="Advanced + Long-tail" />
              <PackageRow feature="On-Page Optimization" basic="✅" standard="✅" premium="✅ (Full site)" />
              <PackageRow feature="Meta Tags" basic="10 pages" standard="25 pages" premium="All pages" />
              <PackageRow feature="Technical SEO" basic="✅" standard="✅" premium="✅ Advanced" />
              <PackageRow feature="Blog Creation" basic="2/month" standard="4/month" premium="8/month" />
              <PackageRow feature="Local SEO (GMB)" basic="Basic" standard="Optimization" premium="Full + Posts" />
              <PackageRow feature="Link Building" basic="40/mo" standard="60/mo" premium="80+ high DA/mo" />
              <PackageRow feature="Reporting" basic="Basic" standard="Detailed" premium="Advanced dashboard" />
              <PackageRow feature="Support" basic="Email" standard="Email + Call" premium="Priority (Call, WhatsApp)" />
            </tbody>
          </table>
        </div>
      </section>

      <section className="container grid cols-3">
        <div className="card">
          <h3 style={{marginTop:0}}>Monthly Deliverables</h3>
          <ul>
            <li>SEO Audit & Progress Report</li>
            <li>Keyword Ranking Update</li>
            <li>Backlink Report</li>
            <li>Traffic & Analytics Report</li>
            <li>Competitor Snapshot</li>
          </ul>
        </div>
        <div className="card">
          <h3 style={{marginTop:0}}>Add-on Services</h3>
          <ul>
            <li>Website Redesign (SEO-friendly)</li>
            <li>Google Ads / Meta Ads</li>
            <li>E-commerce SEO</li>
            <li>Local Citations & Listings</li>
            <li>Video SEO (YouTube)</li>
          </ul>
        </div>
        <div className="card">
          <h3 style={{marginTop:0}}>Get in Touch</h3>
          <p>Email: <a href="mailto:miniparth6@gmail.com">miniparth6@gmail.com</a></p>
          <p>Phone: <a href="tel:+917600875743">+91 7600875743</a></p>
        </div>
      </section>

      <footer className="container">
        © {new Date().getFullYear()} Parth Shah — Digital Marketing & SEO Expert
      </footer>
    </main>
  )
}
