# Parth Shah — SEO Website for Cloudflare Pages (Static Export)

This is a Next.js 14 App Router project configured for **static export**. It deploys perfectly to **Cloudflare Pages**.

## Local preview
```bash
npm install
npm run dev
```

## Build static site
```bash
npm run export
# output will be in the 'out' folder
```

## Deploy to Cloudflare Pages (two ways)

### Option A — Connect Git
1. Push this folder to a new GitHub repo.
2. In Cloudflare → Pages → **Create a project** → **Connect to Git** → select your repo.
3. **Build command:** `npm run export`
4. **Build output directory:** `out`
5. Deploy → your site will be live at `*.pages.dev`.

### Option B — Upload folder
1. Run `npm run export` locally.
2. In Cloudflare Pages → **Upload assets**.
3. Drag-and-drop the generated **out/** folder contents.

## Update your proposal
Replace `public/seo-proposal.pdf` before exporting to update the download link.

---
Notes:
- Static export is used for compatibility and speed on Pages.
- If you later need server-side features, switch to Cloudflare’s `@cloudflare/next-on-pages` adapter.
