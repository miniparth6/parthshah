export const metadata = {
  title: "Parth Shah — SEO Expert",
  description: "Boost Your Online Visibility with Proven SEO Strategies.",
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head />
      <body style={{margin:0,fontFamily:"Inter, system-ui, Arial, sans-serif", background:"#0b1020", color:"#e8ecff"}}>
        {children}
      </body>
    </html>
  );
}
