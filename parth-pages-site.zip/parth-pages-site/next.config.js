/** @type {import('next').NextConfig} */
const nextConfig = {
  // Static export so it works perfectly on Cloudflare Pages
  output: 'export',
  images: { unoptimized: true },
}
module.exports = nextConfig
